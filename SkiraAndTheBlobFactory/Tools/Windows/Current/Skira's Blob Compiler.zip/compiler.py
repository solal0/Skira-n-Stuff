import requests
import base64
import sys
import time
import os
import ctypes
import zipfile
import shutil
import io
import subprocess
import tempfile
import threading
from tkinter import Tk
from tkinter.filedialog import askopenfilename
import concurrent.futures
from math import ceil

VERSION_FILE = "version.txt"
TOOL_URL = "https://solal0.github.io/Skira-n-Stuff/SkiraAndTheBlobFactory/Tools/Windows/Current/Skira's%20Blob%20Compiler.zip"
UPDATER_URL = "https://solal0.github.io/Skira-n-Stuff/SkiraAndTheBlobFactory/Tools/Plus/updater.py"
INFO_FILE = os.path.join(tempfile.gettempdir(), "update_info.tmp")

def decompile_part(encoded_text: str, password: str) -> str:
    try:
        decoded = base64.b64decode(encoded_text).decode("utf-8")
        stored_pw, prefix, rev_payload = decoded.split("::", 2)
        if stored_pw != password:
            print("❌ Password is incorrect.")
            input("Press Enter to close...")
        return prefix + rev_payload[::-1]
    except Exception as e:
        print(f"❌ Failed to decompile private part: {e}")
        input("Press Enter to close...")

def force_console_focus():
    try:
        kernel32 = ctypes.windll.kernel32
        user32 = ctypes.windll.user32
        hWnd = kernel32.GetConsoleWindow()
        if hWnd:
            user32.ShowWindow(hWnd, 9)
            user32.SetForegroundWindow(hWnd)
    except Exception:
        pass

def run_updater():
    print("🔄 Running updater...")
    compiler_parent = os.path.dirname(os.path.abspath(__file__))
    with open(INFO_FILE, "w", encoding="utf-8") as f:
        f.write(compiler_parent)
    try:
        r = requests.get(UPDATER_URL, timeout=20)
        r.raise_for_status()
        updater_path = os.path.join(tempfile.gettempdir(), "updater.py")
        with open(updater_path, "wb") as f:
            f.write(r.content)
    except Exception as e:
        print(f"❌ Failed to download updater.py: {e}")
        input("Press Enter to close...")
    try:
        subprocess.run([sys.executable, updater_path])
    except Exception as e:
        print(f"❌ Failed to run updater.py: {e}")
        input("Press Enter to close...")
    sys.exit(0)

def check_for_updates():
    print("Checking for updates...")

    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    VERSION_PATH = os.path.join(SCRIPT_DIR, VERSION_FILE)

    if not os.path.exists(VERSION_PATH):
        print(f"❌ version.txt missing at: {VERSION_PATH}")
        print("Files in script folder:", os.listdir(SCRIPT_DIR))
        run_updater()

    try:
        with open(VERSION_PATH, "r", encoding="utf-8") as f:
            local_ver = f.read().strip()
    except Exception as e:
        print(f"❌ Failed to read version.txt at {VERSION_PATH}: {e}")
        run_updater()
    try:
        r = requests.get(TOOL_URL, timeout=20)
        r.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            version_name = None
            for name in z.namelist():
                if name.lower().strip().endswith("version.txt"):
                    version_name = name
                    break

            if not version_name:
                print("⚠️ Remote tool has no version.txt, skipping update check.")
                return

            remote_ver = (
                z.read(version_name)
                .decode("utf-8", errors="ignore")
                .strip()
            )

            print(f"✅ Found remote version.txt")
    except Exception as e:
        print(f"⚠️ Could not check remote version: {e}")
        return
    if local_ver != remote_ver:
        print("⚠️ Tool is outdated!")
        run_updater()
    else:
        print("✅ Tool is up to date.")

banner = r"""
 _____ _    _            _        ______ _       _         _____                       _ _           
/  ___| |  (_)          ( )       | ___ \ |     | |       /  __ \                     (_) |Made          
\ `--.| | ___ _ __ __ _ |/ ___    | |_/ / | ___ | |__     | /  \/ ___  _ __ ___  _ __  _| | ___ b̲y__
 `--. \ |/ / | '__/ _` |  / __|   | ___ \ |/ _ \| '_ \    | |    / _ \| '_ ` _ \| '_ \| | |/ _ \ '__|Skira
/\__/ /   <| | | | (_| |  \__ \   | |_/ / | (_) | |_) |   | \__/\ (_) | | | | | | |_) | | |  __/ |   
\____/|_|\_\_|_|  \__,_|  |___/   \____/|_|\___/|_.__/     \____/\___/|_| |_| |_| .__/|_|_|\___|_|   
                                                                               | |                   
Select your golden ticket to proceed.                                          |_|                                                                                           
"""

script_dir = os.path.dirname(os.path.abspath(__file__))
output_folder = os.path.join(script_dir, "Output")
os.makedirs(output_folder, exist_ok=True)
temp_folder = os.path.join(output_folder, ".temp")
os.makedirs(temp_folder, exist_ok=True)

def select_ticket_file():
    Tk().withdraw()
    file_path = askopenfilename(title="Select your golden ticket",
                                filetypes=[("Golden Ticket Files", "*.golden_ticket.json *.txt"), ("All Files", "*.*")])
    if not file_path:
        print("❌ No golden ticket selected. Exiting...")
        sys.exit(0)
    force_console_focus()
    return file_path

def load_ticket(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        clean_lines = [
            line.strip()
            for line in lines
            if line.strip() and not line.strip().startswith("#") and "NAME=" not in line
        ]

        if not clean_lines:
            raise ValueError("Golden ticket contains no valid links.")
        password = None
        if clean_lines[0].startswith("PASSWORD="):
            password = clean_lines[0].split("=", 1)[1].strip()
            parts = clean_lines[1:]
        else:
            parts = clean_lines
        base_name = os.path.basename(file_path)
        output_name = base_name.split(".golden_ticket")[0] if ".golden_ticket" in base_name else os.path.splitext(base_name)[0]
        return output_name, parts, password
    except Exception as e:
        print(f"❌ Error reading golden ticket: {e}")
        input("Press Enter to close...")

def format_duration(seconds):
    if seconds < 60:
        return f"{seconds:.2f} seconds"
    elif seconds < 3600:
        return f"{seconds/60:.2f} minutes"
    else:
        return f"{seconds/3600:.2f} hours"

def format_size(bytes_size):
    for unit in ["B", "KB", "MB", "GB", "TB", "PB", "EB"]:
        if bytes_size < 1024:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.2f} YB"

def get_import_speed(total_parts):
    test_url = "https://raw.githubusercontent.com/solal0/Skira-n-Stuff/refs/heads/main/SkiraAndTheBlobFactory/Dump/10Mb.txt"
    print("⚙️ Testing your system and connection speed...")
    
    measured_speed_mb_s = None
    try:
        start = time.time()
        r = requests.get(test_url, stream=True, timeout=20)
        r.raise_for_status()
        size_bytes = 0
        for chunk in r.iter_content(chunk_size=8192):
            size_bytes += len(chunk)
        elapsed = time.time() - start
        measured_speed_mb_s = (size_bytes / (1024 * 1024)) / elapsed
        print(f"✅ Measured speed: {measured_speed_mb_s:.2f} MB/s (based on {format_size(size_bytes)} in {format_duration(elapsed)})")
    except Exception as e:
        print(f"⚠️ Speed test failed ({e}), falling back to default 10 MB/s estimate.")
        measured_speed_mb_s = 10.0

    part_size_bytes = 10 * 1024 * 1024
    total_size = total_parts * part_size_bytes
    total_mb = total_size / (1024 * 1024)

    fast_time_sec = total_mb / measured_speed_mb_s
    slow_time_sec = fast_time_sec * 1.5

    print("\nChoose importation speed:")
    print(f"1. Slow (recommended, safer) | AVG: [{format_duration(slow_time_sec)}] | Size: [{format_size(total_size)}]")
    print(f"2. Fast (optimistic)         | AVG: [{format_duration(fast_time_sec)}] | Size: [{format_size(total_size)}]")
    choice = input("Enter 1 for Slow or 2 for Fast: ").strip()
    return "fast" if choice == "2" else "slow"

def download_part(url, password, idx, total, delay, retries, retry_delay, temp_dir):
    filename = f"part_{idx:05d}"
    filepath = os.path.join(temp_dir, filename)
    attempt = 0
    while attempt < retries:
        try:
            print(f"⏳ [{idx}/{total}] Downloading {url}... (attempt {attempt+1})")
            r = requests.get(url, timeout=30)
            r.raise_for_status()
            text = r.text.strip()
            if text.startswith("data:application/octet-stream;base64,"):
                text = text.split(",", 1)[1]
            text = ''.join(text.split())
            if password:
                text = decompile_part(text, password).split(",", 1)[1]
            decoded = base64.b64decode(text)
            with open(filepath, "wb") as f:
                f.write(decoded)
            print(f"✅ [{idx}/{total}] Has been imported.")
            if delay > 0:
                time.sleep(delay)
            return filepath
        except Exception as e:
            attempt += 1
            print(f"⚠️ Error with part {idx}: {e}")
            if attempt < retries:
                print(f"Retrying in {retry_delay}s...")
                time.sleep(retry_delay)
            else:
                print(f"❌ Failed to download part {idx}")
                input("Press Enter to close...")


def download_and_merge_in_order(parts, delay, max_threads, password, output_path):
    total_files = len(parts)
    temp_dir = os.path.join(output_folder, ".temp")
    os.makedirs(temp_dir, exist_ok=True)

    start_time = time.time()

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
        future_map = {
            executor.submit(download_part, url, password, i+1, total_files, delay, 5, 5, temp_dir): i+1
            for i, url in enumerate(parts)
        }
        concurrent.futures.wait(future_map)

    print("\n🔗 Merging all parts in order...")
    with open(output_path, "wb") as final_file:
        for i in range(1, total_files+1):
            part_file = os.path.join(temp_dir, f"part_{i:05d}")
            with open(part_file, "rb") as pf:
                shutil.copyfileobj(pf, final_file)
            os.remove(part_file)
            print(f"📦 [{i}/{total_files}] Has been added")

    os.rmdir(temp_dir)
    elapsed = time.time()- start_time
    print(f"\n🎉 Importation and Compiling done!")
    print(f"[DEBUG] ⏱ Total time: {format_duration(elapsed)}")
    print(f"[DEBUG] You can find your file at: {os.path.abspath(output_path)}")
    input(f"\nPress Enter to close...")

if __name__ == "__main__":
    check_for_updates()
    print(banner)

    ticket_file = select_ticket_file()
    output_name, parts, password = load_ticket(ticket_file)
    output_path = os.path.join(output_folder, output_name)

    if password:
        print("🔒 Password found. Encrypted parts will be decompiled during import.\n")

    speed = get_import_speed(len(parts))
    delay = 0.5 if speed == "slow" else 0.1
    max_threads = 16 if speed == "fast" else 8

    download_and_merge_in_order(parts, delay, max_threads, password, output_path)
